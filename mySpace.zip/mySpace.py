from __future__ import print_function

import string
import json
import boto3
import httplib
import time
import urllib

""" deal_with_API_request receives the calling event dictionary and the name of
the services state table.
"""
def deal_with_API_request(event, state_table):
    if event['http_method'] == 'GET': 
        if event['resource_path'] == '/':
            obj = {
                "test" : "we made it new",
                "next" : "who knows"
                }
            return obj

    if event['http_method'] == 'POST':
        if event['resource_path'] == '/':
            # collect information from payload
            obj = {
                "test" : "made it to POST",
                "next" : "returning"
                }
            return obj
        else:
            raise Exception('NotFound')
    # should never get here
    raise Exception('MethodNotAllowed')


""" mySpace() is installed when a new mySpace is created. It is them used to
list installed services, install new services, and delete services that are no 
longer desired.
"""
def mySpace(event, context):
    # test to see if called via API
    if 'resource_path' in event:
        return deal_with_API_request(event, context.function_name)
